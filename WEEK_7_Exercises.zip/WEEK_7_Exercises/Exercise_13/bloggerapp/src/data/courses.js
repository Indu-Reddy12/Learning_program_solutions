export const courses = [
  { id: 1, cname: 'Angular', date: '04/05/2021' },
  { id: 2, cname: 'React', date: '06/03/2021' }
];
